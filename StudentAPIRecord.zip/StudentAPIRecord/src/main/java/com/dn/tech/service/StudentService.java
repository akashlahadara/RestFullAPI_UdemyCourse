package com.dn.tech.service;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dn.tech.dao.CourseDAO;
import com.dn.tech.dao.StudentDAO;
import com.dn.tech.dto.StudentDTO;
import com.dn.tech.exception.EmailAlerdyExist;
import com.dn.tech.exception.StudentNotFoundException;
import com.dn.tech.model.Student;

@Service
public class StudentService {
    
    @Autowired
    private StudentDAO dao;
    
    @Autowired
    private CourseDAO cdao;
    
    public StudentDTO saveStudentRecord(StudentDTO dto) {
    	if(dao.existsByEmail(dto.getEmail()))
    	{
    		throw new EmailAlerdyExist("Email Alredy Exist Please Try with Differnt Email");
    	}
        Student student = new Student();
        BeanUtils.copyProperties(dto, student);
        Student savedStudent = dao.save(student);
        BeanUtils.copyProperties(savedStudent, dto);
        return dto;
    }
    public StudentDTO updateStudentRecord(StudentDTO dto)
    {
    	if(!dao.existsById(dto.getId()))
    	{
    		throw new StudentNotFoundException("Student is Not Exist in Database for Update the Record for Given id: "+dto.getId());
    	}
    	Student st=new Student();
    	BeanUtils.copyProperties(dto, st);
    	Student st1=dao.save(st);
    	BeanUtils.copyProperties(st1,dto);
    	return dto;
    }
    public StudentDTO getSingleRecordForStudent(Long Id)
    {
    	Optional<Student> st=dao.findById(Id);
    	if(!st.isPresent())
    	{
    		throw new StudentNotFoundException("Student is Not Exist in Databasefor Given id: ");
    	}
    	StudentDTO dto=new StudentDTO();
    	BeanUtils.copyProperties(st.get(), dto);
    	return dto;
    }
}
