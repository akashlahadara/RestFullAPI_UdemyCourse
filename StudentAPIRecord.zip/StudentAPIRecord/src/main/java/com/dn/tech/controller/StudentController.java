package com.dn.tech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dn.tech.dto.StudentDTO;
import com.dn.tech.service.StudentService;

@RestController
public class StudentController {
	public StudentController() {
		System.out.println("Student Rest Controler");
	}
	@Autowired
	private StudentService ss;
	@PostMapping("/saveStudent")
	public StudentDTO saveStudent(@RequestBody  StudentDTO dto)
	{
		StudentDTO nsdto=ss.saveStudentRecord(dto);
		return nsdto;
	}
	
	@PutMapping("/updateStudent")
	public StudentDTO updateStudent(@RequestBody  StudentDTO dto)
	{
		StudentDTO nsdto=ss.updateStudentRecord(dto);
		return nsdto;
	}
	
	@GetMapping("/getById/{id}")
	public StudentDTO fatchSingleStudentRecord(@PathVariable("id") Long id)
	{
		StudentDTO nsdto=ss.getSingleRecordForStudent(id);
		return nsdto;
	}
}
