package com.dn.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentApiRecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentApiRecordApplication.class, args);
	}

}
