package com.dn.tech.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dn.tech.model.Course;

public interface CourseDAO extends JpaRepository<Course,Long> {

}
