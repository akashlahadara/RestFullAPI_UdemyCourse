package com.dn.tech.dto;

import java.util.List;

import com.dn.tech.model.Course;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StudentDTO {
	public StudentDTO() {
		System.out.println("StudentDTO Class Object Created");
	}
	private Long id;
	private String name;
	private String email;
	private String address;
	private Long mobileno;
	private List<Course> course; 
}
