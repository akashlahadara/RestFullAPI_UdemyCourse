package com.dn.tech.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CourseDTO {
	public CourseDTO()
	{
		System.out.println("CourseDTO Class Object Created");
	}
	private Long id;
	private String courseName;
	private String courseDesc;
	private int courseFee;
	private int courseDuration;
}
